/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form_tiketpesawat;

import java.util.ArrayList;

/**
 *
 * @author Dosen C-04
 */
public class ModelMaskapai {
    private String namaMaskapai;
    private ArrayList<modelrute>rute=new ArrayList<>();

public modelMaskapai(String namaMaskapai){
    this.namaMaskapai=namaMaskapai;
}
@Override
public String toString(){
    return namaMaskapai;
}
/**
 * @return the namaMaskapai
 */
public String getNamaMaskapai(){
    return namaMaskapai;
}
/**
 * @param namaMaskapai the namaMaskapai to set
 */
public void setNamaMaskapai(String namaMaskapai){
    this.namaMaskapai = namaMaskapai;
}
/**
 * @return the rute
 */
public ArrayList<modelrute> getRute(){
    return rute;
}
/**
 * @param rute the rute to set
*/
}
public void addRute(ModelRute rute){
    this.rute.add(rute);
}
}

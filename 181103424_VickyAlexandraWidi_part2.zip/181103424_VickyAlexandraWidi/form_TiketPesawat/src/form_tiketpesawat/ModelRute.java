/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package form_tiketpesawat;

/**
 *
 * @author Dosen C-04
 */
public class ModelRute {
    private String rute;
    private String lamaPerjalanan;
    private float harga;
    
    public ModelRute(String rute, String lamaPerjalanan, float harga){
        this.rute = rute;
        this.lamaPerjalanan = lamaPerjalanan;
        this.harga = harga;
    }
    @Override
    public String toString(){
        return rute;
    }
    /**
     * @return the rute
     */
    public String getRute(){
        return rute;
    }
    /**
     * @return the lamaPerjalanan 
     */
    public String getLamaPerjalanan(){
        return lamaPerjalanan;
    }
    /**
     * @return the harga
     */
    public float getHarga(){
        return harga;
    }  
}

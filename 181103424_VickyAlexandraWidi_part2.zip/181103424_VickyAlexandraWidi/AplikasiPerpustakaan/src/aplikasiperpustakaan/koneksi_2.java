/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplikasiperpustakaan;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Dosen C-04
 */
public class koneksi_2 {
Connection con;
public Connection getConnection(){
    try{
        con = DriverManager.getConnection("jdbo:mysql://localhost, perpustakaan","root","");
    }
    catch (Excepyion e) {
        JOptionPane.showMessageDialog(null, "Koneksi GAGAL \n"+e);
    }
    return con;
}
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package agenperjalanan;

import java.util.ArrayList;

/**
 *
 * @author master
 */
public class ModelMaskapai {
    private String namaMaskapai;
    private ArrayList<ModelRute> rute=new ArrayList<>();

    public ModelMaskapai(String namaMaskapai){
        this.namaMaskapai=namaMaskapai;
    }
    
    @Override
    public String toString(){
        return namaMaskapai;
    }
    /**
     * @return the namaMaskapai
     */
    public String getNamaMaskapai() {
        return namaMaskapai;
    }

    /**
     * @param namaMaskapai the namaMaskapai to set
     */
    public void setNamaMaskapai(String namaMaskapai) {
        this.namaMaskapai = namaMaskapai;
    }

    /**
     * @return the rute
     */
    public ArrayList<ModelRute> getRute() {
        return rute;
    }

    /**
     * @param rute the rute to set
     */
    public void addRute(ModelRute rute) {
        this.rute.add(rute);
    }
}

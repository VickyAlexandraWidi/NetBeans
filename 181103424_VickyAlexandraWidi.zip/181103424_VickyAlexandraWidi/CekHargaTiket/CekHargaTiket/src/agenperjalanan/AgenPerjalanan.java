/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package agenperjalanan;

/**
 *
 * @author master
 */
public class AgenPerjalanan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        UIRutePerjalanan perjalanan = new UIRutePerjalanan();
        perjalanan.setVisible(true);
    }
}
